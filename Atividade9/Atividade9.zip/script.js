/*  Criar duas funções:Uma que receba três números como parâmetros e retorne o maior deles. Usar um arquivo js externo. 
    Outra que receba três números e coloque em ordem crescente. 
    Disponibilizar  como  Atividade9  no GITHUB. Seunome/PWEB/Atividade9  */

    function Maior() {
        var a = parseInt(document.querySelector("#num1").value);
        var b = parseInt(document.querySelector("#num2").value);
        var c = parseInt(document.querySelector("#num3").value);

        alert ((a>b && a>c)?a: (b>a && b>c)?b: c);
        return ((a>b && a>c)?a: (b>a && b>c)?b: c);
    }

    function OrdemCresce() {
        var a = parseInt(document.querySelector("#num1").value);
        var b = parseInt(document.querySelector("#num2").value);
        var c = parseInt(document.querySelector("#num3").value);
        var pri;
        var seg;
        var ter;

        if(a < b && a < c){
            pri = a;

            if(b < c){
                seg = b;
                ter = c;
            } else {
                seg = c;
                ter = b;
            }
        } else if (b < a && b < c){
            pri = b;

            if(a < c){
                seg = a;
                ter = c;
            } else {
                seg = c;
                ter = a;
            }
        } else{
            pri = c;

            if(a < b){
                seg = a;
                ter = b;
            } else {
                seg = b;
                ter = a;
            }
        }

        var points = [pri, seg, ter]
        alert (points);
        return points;
    }