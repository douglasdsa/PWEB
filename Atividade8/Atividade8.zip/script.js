var pesquisa = new Array(45);
var mediaIdade = 0, idadeMaisVelho = 0, idadeMaisNovo = 999, qtdePessimo = 0, qtdeOtimo = 0, qtdeBom = 0, qtdeMulheres = 0, qtdeHomens = 0;

function Pesquisa() {
    let idade;
    let sexo;
    let opiniao; //ótimo = 4 / bom = 3 / regular = 2 / péssimo = 1
} 

for(let i = 0; i < pesquisa.length; i++){
    pesquisa[i] = new Pesquisa();

    pesquisa[i].idade = parseInt(prompt("Digite a idade do " + (i+1) + "° entrevistado: "));
    pesquisa[i].sexo = prompt("Digite o sexo do " + (i+1) + "° entrevistado (M ou F): ");
    pesquisa[i].opiniao = parseInt(prompt("Digite a opinião do " + (i+1) + "° entrevistado (ótimo = 4 / bom = 3 / regular = 2 / péssimo = 1): "));

    if(idadeMaisVelho < pesquisa[i].idade){
        idadeMaisVelho = pesquisa[i].idade;
    }

    if(idadeMaisNovo > pesquisa[i].idade){
        idadeMaisNovo = pesquisa[i].idade;
    }

    if(pesquisa[i].opiniao === 1){
        qtdePessimo++;
    } else if(pesquisa[i].opiniao === 3){
        qtdeBom++;
    } else if(pesquisa[i].opiniao === 4){
        qtdeOtimo++;
    }

    if(pesquisa[i].sexo === "m" || pesquisa[i].sexo === "M"){
        qtdeHomens++;
    } else if(pesquisa[i].sexo === "f" || pesquisa[i].sexo === "F"){
        qtdeMulheres++;
    }
}

for(let i = 0; i < pesquisa.length; i++){
    mediaIdade += pesquisa[i].idade;
}

alert("Média de idade: " + (mediaIdade / pesquisa.length));
alert("Idade da pessoa mais velha: " + idadeMaisVelho);
alert("Idade da pessoa mais nova: " + idadeMaisNovo);
alert("Quantidade de pessoas que responderam péssimo: " + qtdePessimo);
alert("Porcentagem de pessoas que responderam ótimo: " + ((qtdeOtimo * 100) / pesquisa.length) + "%");
alert("Porcentagem de pessoas que responderam bom: " + ((qtdeBom * 100) / pesquisa.length) + "%");
alert(qtdeMulheres + " mulher(es) respondeu(ram) ao questionário");
alert(qtdeHomens + " homem(ns) respondeu(ram) ao questionário");