var app = require('./app/config/server'); //carregando o módulo do servidor

var rotaHome = require('./app/routes/home')(app);

var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario')(app);

var rotaHistoria = require('./app/routes/historia')(app);

var rotaCursos = require('./app/routes/cursos')(app);

var rotaProfessores = require('./app/routes/professores')(app); // está executando 

app.listen(3000, function(){
    console.log("servidor iniciado");
});