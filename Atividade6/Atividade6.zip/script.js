//alert("Alô mundo!");
//confirm();

// ---------------- 1 ----------------
var nomeAluno = prompt("Digite o nome do aluno");
var nota1 = parseFloat(prompt("Nota 1"));
var nota2 = parseFloat(prompt("Nota 2"));
var nota3 = parseFloat(prompt("Nota 3"));

var notaGeral = (nota1 + nota2 + nota3) / 3;

alert("Media Aritmetica do aluno " + nomeAluno + " " + notaGeral);

// ---------------- 2 ----------------
var num1 = parseFloat(prompt("Digite o numero 1"));
var num2 = parseFloat(prompt("Digite o numero 2"));

//Soma
var soma = num1 + num2;
alert("Soma dos dois numeros: " + soma);

//Subtracao
var sub = num1 - num2;
alert("Subtracao do primeiro pelo segundo: " + sub);

//Produto
var prod = num1 * num2;
alert("Produto dos dois numeros: " + prod);

//Divisao
var div = num1 / num2;
alert("Divisao do primeiro pelo segundo: " + div);

//Resto da divisao
var restDiv = num1 % num2;
alert("Resto da divisao do primeiro pelo segundo: " + restDiv);