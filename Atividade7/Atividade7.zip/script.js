function Resultado() { 
    var escolhaUsuario = parseInt(document.querySelector("#Escolha").value);
    var escolhaMaquina = Math.random();

    if(escolhaMaquina < 0.33){
        escolhaMaquina = 0;
    } 
    else if(escolhaMaquina < 0.66){
        escolhaMaquina = 1;
    }
    else{
        escolhaMaquina = 2;
    }

    if(escolhaUsuario === 0 && escolhaMaquina === 2){
        alert("Você venceu!\n\nUsuário: Pedra\nMáquina: Tesoura");
    }
    else if(escolhaUsuario === 1 && escolhaMaquina === 0){
        alert("Você venceu!\n\nUsuário: Papel\nMáquina: Pedra"); 
    }
    else if(escolhaUsuario === 2 && escolhaMaquina === 1){
        alert("Você venceu!\n\nUsuário: Tesoura\nMáquina: Papel"); 
    }
    else if(escolhaUsuario === 0 && escolhaMaquina === 0){
        alert("Empate!\n\nUsuário: Pedra\nMáquina: Pedra"); 
    }
    else if(escolhaUsuario === 1 && escolhaMaquina === 1){
        alert("Empate!\n\nUsuário: Papel\nMáquina: Papel"); 
    }
    else if(escolhaUsuario === 2 && escolhaMaquina === 2){
        alert("Empate!\n\nUsuário: Tesoura\nMáquina: Tesoura"); 
    }
    else if(escolhaUsuario === 0 && escolhaMaquina === 1){
        alert("Você perdeu!\n\nUsuário: Pedra\nMáquina: Papel"); 
    }
    else if(escolhaUsuario === 1 && escolhaMaquina === 2){
        alert("Você perdeu!\n\nUsuário: Papel\nMáquina: Tesoura"); 
    }
    else if(escolhaUsuario === 2 && escolhaMaquina === 0){
        alert("Você perdeu!\n\nUsuário: Tesoura\nMáquina: Pedra"); 
    }
    else{
        alert("Bug!\n\nUsuário: " + escolhaUsuario + "\nMáquina: " + escolhaMaquina); 
    }   
};